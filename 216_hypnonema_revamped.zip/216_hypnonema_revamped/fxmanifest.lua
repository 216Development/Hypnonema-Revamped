fx_version 'cerulean'
game 'gta5'

author '216 Development' -- optional 
description 'Hypnonema Revamped | Discord: https://discord.gg/216development' -- optional 
version '1.0.0' -- optional 

this_is_a_map 'yes'